import { TestBed } from '@angular/core/testing';

import { CouponsServiceService } from './coupons-service.service';

describe('CouponsServiceService', () => {
  let service: CouponsServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CouponsServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
