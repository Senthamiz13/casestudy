import { Component, OnInit } from '@angular/core';
import { CouponsServiceService } from '../coupons-service.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})

export class HomeComponent implements OnInit {

  public ListOfCoupons:any = [];

  //images = [944, 1011, 984].map((n) => `https://picsum.photos/id/${n}/900/500`);

  constructor(private couponservice:CouponsServiceService) { }

  ngOnInit(): void {
    this.couponservice.get().subscribe(response=>{
      this.ListOfCoupons = response;
      //console.log(JSON.stringify(response));
      console.log(this.ListOfCoupons);
    },
    error=>{
      console.log(error)
    })
}

public getImg(provider:String){
  //console.log(provider);
  //console.log("getImg Called");
  // var scrimg = "default";
  // switch (provider){

  //   case "Amazon":
  //     scrimg = "amazon";
  //   break;

  //   case "Flipkart":
  //     scrimg = "flipkart";
  //   break;

  //   case "Snapdeal":
  //     scrimg = "snapdeal";
  //   break;

  //   case "Myntra":
  //     scrimg = "myntra";
  //   break;

  // }
  return "assets/images/provider/"+provider+".png";
}

}






