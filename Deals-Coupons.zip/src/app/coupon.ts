export class coupon {
    constructor(
        public provider:String,
        public code:String,
        public category:String,
        public description:String
    ){}
}
