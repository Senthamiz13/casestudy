import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { throwError } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';
import { coupon } from './coupon';

@Injectable({
  providedIn: 'root'
})
export class CouponsServiceService {


  _url = "http://localhost:8080/coupons/coupons"; ///API Gateway
  // _url = "http://localhost:8082/coupons";
  messageSuccess: boolean | undefined;
  
  constructor(private _http:HttpClient) { }

  public add(c:coupon){
    console.log(c);
    console.log(JSON.stringify(c));
    var cal =  this._http.post(this._url+"/add",c, { observe: 'response', responseType: 'text'}).subscribe();
    // return cal;
  }

  // public get(){
  //     var our =  this._http.get(this._url+"/all");
  //     console.log(our);
  //     return our;
  // }

  public get(){

    // let authorizationData = 'Basic ' + btoa("sen:sen");

    // const headerOptions = {
    //     headers: new HttpHeaders({
    //         //'Content-Type':  'application/json',
    //         'Authorization': authorizationData
    //     })
    // };
    //var our =  this._http.get(this._url+"/all",{headers: headerOptions});

      // let httpHeaders = new HttpHeaders();
      // httpHeaders.append('Content-Type', 'application/json');
      // httpHeaders.append("Authorization", "Basic" + btoa("sen:sen"));

      // console.log("-------------------------");
      // console.log(HttpHeaders);
      // console.log("-------------------------");


      // const httpOptions = {
      //   headers: httpHeaders
      // };

      // console.log(httpOptions.headers);

      const headers = new HttpHeaders({ Authorization: 'Basic ' + btoa("sen:sen") });

      var our =  this._http.get(this._url+"/all",{headers});


    console.log(our);
    return our;
}

  public deleteCoupon(ID:String){
    console.log(this._url+"/delete/"+ID);
    var our =  this._http.delete(this._url+"/delete/"+ID);
    console.log(our);
    return our;
  }
}

