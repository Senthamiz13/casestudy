package com.casestudy.userDetails.repository;

import com.casestudy.userDetails.model.userDetails;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface userDetailsRepository extends MongoRepository<userDetails,String> {

    @Query(value="{}", fields="{username : 1, _id : 0}")
    String findpass();
}
