package com.casestudy.userDetails.controller;

import com.casestudy.userDetails.model.Auth;
import com.casestudy.userDetails.model.BasicUserDetails;
import com.casestudy.userDetails.model.userDetails;
import com.casestudy.userDetails.repository.BasicUserDetailsRepository;
import com.casestudy.userDetails.repository.userDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user")
public class controller {

    @Autowired
    private userDetailsRepository userDetailsRepository;

    @Autowired
    private BasicUserDetailsRepository basicUserDetailsRepository;

    @GetMapping(value = "/all")
    public List<userDetails> getAllDeals() {
        return userDetailsRepository.findAll();
    }

    @PostMapping(value = "/add")
    public userDetails adduser(@RequestBody userDetails user){
        System.out.println(user);
        return userDetailsRepository.save(user);
    }

    @PostMapping(value = "/update")
    public userDetails updatedetails(@RequestBody BasicUserDetails user){

        System.out.println("update method called");
        //System.out.println(user);

        userDetails details = userDetailsRepository.findById(user.getUsername()).orElse(null);

        details.setCashbackPoints(user.getCashbackPoints());
        details.setListOfCoupons(user.getListOfCoupons());
        details.setPreferences(user.getPreferences());

        return userDetailsRepository.save(details);
    }

    @GetMapping(value = "/getuser/{name}")
    public Optional<BasicUserDetails> getbasicdetails(@PathVariable String name)
    {
        return basicUserDetailsRepository.findById(name);
    }

    @PostMapping(value = "/auth")
    public String getpassword(@RequestBody Auth postedauth){
        System.out.println(postedauth.getUsername());
        System.out.println(postedauth.getPassword());
        Optional<userDetails> user = userDetailsRepository.findById(postedauth.getUsername());

        if (user.isPresent()) {
            userDetails user1 = user.get();
//            System.out.println(user1.getPassword());
//            System.out.println(postedauth.getPassword());
            if (postedauth.getPassword().equals(user1.getPassword())){
                return "true";
            }
            else return "false";
        }
        else return "false";
    }

}
