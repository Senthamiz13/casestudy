package com.casestudy.coupons.Resource;
import com.casestudy.coupons.Models.Coupons;
import com.casestudy.coupons.Repository.CouponRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.casestudy.coupons.*;

import java.util.List;

//@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/coupons")
public class Controller {

    @Autowired
    private CouponRepository couponRepository;

    @GetMapping(value = "/all")
    public List<Coupons> getAllCoupons(){
        System.out.println("GET method called");
        return couponRepository.findAll();
    }

    @PostMapping(value = "/add")
    public Coupons addCoupon(@RequestBody Coupons coupons){
        System.out.println("add method called");
        return couponRepository.save(coupons);
    }

    @PostMapping(value = "/addall")
    public List<Coupons> addListOfCoupons(@RequestBody List<Coupons> couponsList){
        return  couponRepository.insert(couponsList);
    }

    @DeleteMapping(value = "/delete/{couponID}")
    public void deleteProduct(@PathVariable String couponID) {
        System.out.println("Delete method called");
        couponRepository.deleteById(couponID);
    }

    @RequestMapping("/ping/{ping}")
    public String ping(@PathVariable("ping") String ping){
        return "hello "+ping;
    }
}
