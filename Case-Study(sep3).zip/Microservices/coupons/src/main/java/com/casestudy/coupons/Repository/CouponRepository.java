package com.casestudy.coupons.Repository;

import com.casestudy.coupons.Models.Coupons;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface CouponRepository extends MongoRepository<Coupons, String> {
    List<Coupons> findBycategory(String preference);
}
