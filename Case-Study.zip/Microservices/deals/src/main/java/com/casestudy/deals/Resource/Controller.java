package com.casestudy.deals.Resource;

import com.casestudy.deals.Models.Deals;
import com.casestudy.deals.Repository.DealsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/deals")

public class Controller {

    private static final Logger log = LoggerFactory.getLogger(Controller.class);

    @Autowired
    private DealsRepository dealsRepository;

    @GetMapping(value = "/all")
    public List<Deals> getAllDeals() {
        log.info("Get request for all Deals");
        return dealsRepository.findAll();
    }

    @PostMapping (value = "/add")
    public Deals addDeals(@RequestBody Deals deals){
        log.info("Post request for add Deals");
        return dealsRepository.save(deals);
    }

    @PostMapping(value = "/addall")
    public List<Deals> addListOfDeals(@RequestBody List<Deals> dealsList){
        log.info("Post request for add all Deals");
        return  dealsRepository.insert(dealsList);
    }

    @DeleteMapping (value="/delete/{dealId}")
    public void deleteDeals(@PathVariable String dealId) {
        log.info("Delete request for Delete Deal");
        dealsRepository.deleteById(dealId);
    }
}
