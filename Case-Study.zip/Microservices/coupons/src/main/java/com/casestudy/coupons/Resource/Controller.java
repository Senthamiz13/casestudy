package com.casestudy.coupons.Resource;
import com.casestudy.coupons.Models.Coupons;
import com.casestudy.coupons.Repository.CouponRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/coupons")
public class Controller {

    private static final Logger log = LoggerFactory.getLogger(Controller.class);

    @Autowired
    private CouponRepository couponRepository;

    @GetMapping(value = "/all")
    public List<Coupons> getAllCoupons(){
        log.info("Get request for all coupons");
        return couponRepository.findAll();
    }

    @PostMapping(value = "/add")
    public Coupons addCoupon(@RequestBody Coupons coupons){
        log.info("Post request for add coupon");
        return couponRepository.save(coupons);
    }

    @PostMapping(value = "/addall")
    public List<Coupons> addListOfCoupons(@RequestBody List<Coupons> couponsList){
        log.info("Post request for add all coupons");
        return  couponRepository.insert(couponsList);
    }

    @DeleteMapping(value = "/delete/{couponID}")
    public void deleteProduct(@PathVariable String couponID) {
        log.info("Post request for delete  coupon");
        couponRepository.deleteById(couponID);
    }

    @RequestMapping("/ping/{ping}")
    public String ping(@PathVariable("ping") String ping){
        log.info("Get request for ping");
        return "hello "+ping;
    }
}
