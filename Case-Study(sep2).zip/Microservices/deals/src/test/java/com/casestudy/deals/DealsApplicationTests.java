package com.casestudy.deals;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DealsApplicationTests {

	@Test
	void contextLoads() {
	}

}
