package com.casestudy.deals.Resource;

import com.casestudy.deals.Models.Deals;
import com.casestudy.deals.Repository.DealsRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
class ControllerTest {

    @MockBean
    private DealsRepository dealsRepository;

    @Autowired
    private  Controller controller;


    @Test
    void getAllDeals() {
        when(dealsRepository.findAll()).thenReturn(
                Stream.of(
                        new Deals("id","provider","catagory","description","link"))
                        .collect(Collectors.toList()));
        assertEquals(1,controller.getAllDeals().size());
    }

    @Test
    void addDeals() {
    }

    @Test
    void addListOfDeals() {
    }

    @Test
    void deleteDeals() {
    }
}