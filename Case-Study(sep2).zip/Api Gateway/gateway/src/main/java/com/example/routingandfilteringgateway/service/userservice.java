package com.example.routingandfilteringgateway.service;

import com.example.routingandfilteringgateway.controller.controller;
import com.example.routingandfilteringgateway.model.user;
import com.example.routingandfilteringgateway.repository.userDetails;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Service
public class userservice implements UserDetailsService {

    private static Logger log = LoggerFactory.getLogger(userservice.class);


    @Autowired
    userDetails details;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        Optional<user> user = details.findById(username);

        if(user == null) {
            log.warn("User not found");
            throw new UsernameNotFoundException("User not found");}

        List<SimpleGrantedAuthority> authorities = Arrays.asList(new SimpleGrantedAuthority("user"));

        return new User(user.get().getUsername(), user.get().getPassword(), authorities);
    }
}
