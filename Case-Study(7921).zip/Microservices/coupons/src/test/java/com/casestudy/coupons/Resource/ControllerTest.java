package com.casestudy.coupons.Resource;

import com.casestudy.coupons.Models.Coupons;
import com.casestudy.coupons.Repository.CouponRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
class ControllerTest {

    @MockBean
    private CouponRepository couponRepository;

    @Autowired
    private  Controller controller;


    @Test
    void getAllCoupons() {
        when(couponRepository.findAll()).thenReturn(
                Stream.of(
                                new Coupons("id","provider","code","category","description"),
                                new Coupons("id","provider","code","category","description"))
                        .collect(Collectors.toList()));
        assertEquals(2,controller.getAllCoupons().size());

    }

    @Test
    void addCoupon() {
        Coupons coupons = new Coupons("id","provider","code","category","description");
        when(couponRepository.save(coupons)).thenReturn(coupons);
        assertEquals(coupons,controller.addCoupon(coupons));
    }

    @Test
    void addListOfCoupons() {
        List<Coupons> couponsList = Arrays.asList(
                new Coupons("id","provider","code","category","description"),
                new Coupons("id","provider","code","category","description")
        );

        when(couponRepository.insert(couponsList)).thenReturn(couponsList);
        assertEquals(couponsList,controller.addListOfCoupons(couponsList));
    }

    @Test
    void deleteProduct() {
        Coupons coupons = new Coupons("1","provider","category","description","link");
        couponRepository.deleteById("1");
        verify(couponRepository).deleteById("1");
    }

    @Test
    void getcatagory() {
        List<Coupons> couponsList = Arrays.asList(
                new Coupons("id","provider","code","Mobile","description"),
                new Coupons("id","provider","code","category","description")
        );

        when(couponRepository.findAll()).thenReturn(couponsList);
//        when(couponRepository.findBycategory("Mobile")).thenReturn(
//                (List<Coupons>) new Coupons("id","provider","code","Mobile","description")
//        );

        assertEquals(couponsList,controller.getcatagory("All"));
    }

    @Test
    void ping() {
    }
}