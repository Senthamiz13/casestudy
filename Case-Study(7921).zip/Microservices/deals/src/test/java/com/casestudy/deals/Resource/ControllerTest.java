package com.casestudy.deals.Resource;

import com.casestudy.deals.Models.Deals;
import com.casestudy.deals.Repository.DealsRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@SpringBootTest
class ControllerTest {

    @MockBean
    private DealsRepository dealsRepository;

    @Autowired
    private  Controller controller;


    @Test
    void getAllDeals() {
        when(dealsRepository.findAll()).thenReturn(
                Stream.of(
                        new Deals("id","provider","catagory","description","link"),
                        new Deals("id","provider","catagory","description","link"))
                        .collect(Collectors.toList()));
        assertEquals(2,controller.getAllDeals().size());
    }

    @Test
    void addDeals() {
        Deals deal = new Deals("id","provider","catagory","description","link");
        when(dealsRepository.save(deal)).thenReturn(deal);
        assertEquals(deal,controller.addDeals(deal));
    }

    @Test
    void addListOfDeals() {

        List<Deals>dealsList = Arrays.asList(
                new Deals("id","provider","catagory","description","link"),
                new Deals("id","provider","catagory","description","link")
        );

        when(dealsRepository.insert(dealsList)).thenReturn(dealsList);
        assertEquals(dealsList,controller.addListOfDeals(dealsList));
    }

    @Test
    void deleteDeals() {
//        Deals deal = new Deals("1","provider","category","description","link");
//        when(dealsRepository.deleteById("1")).thenReturn(void)
    }
}